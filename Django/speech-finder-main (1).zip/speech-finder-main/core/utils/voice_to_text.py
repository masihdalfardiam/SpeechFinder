def voice_to_text():
    return "this the text that been in the voice."